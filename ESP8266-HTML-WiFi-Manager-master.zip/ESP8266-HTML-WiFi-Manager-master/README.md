#Simple HTML page to Configure your ESP8266




This works with the ESP8266 Arduino platform with a recent stable release(2.0.0 or newer) 
