
<?php
@error_reporting(0);
@session_start();
@ini_set('output_buffering',0);
@ini_set('display_errors', 0);
@set_time_limit(0);
@$pass = $_POST['pass'];
$check_pass = true;
$password = "chiyeuminhem";
$self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
if(isset($_POST['Marion001-Dep-Trai'])) {
session_destroy();
echo'<center><h1>&#272;&#259;ng Xu&#7845;t Th&#224;nh C&#244;ng</h1></center><meta http-equiv="refresh" content="2;URL='.$self.'">';
exit;
}
if($pass == $password)
{
$_SESSION['checklogin1'] = "$pass";
}
if($check_pass == true)
{
if(!isset($_SESSION['checklogin1']) or $_SESSION['checklogin1'] != $password)
{
die("<title>Wifi Web Server ioT</title>

	<meta property='og:url'           content='http://tuyenyeuem.tk/wifi/'>
	<meta property='og:type'          content='Wifi WebServer'>
	<meta property='og:title'         content='V&#361; Tuy&#7875;n Wifi WebServer'>
	<meta property='og:description'   content='&#272;i&#7873;u Khi&#7875;n Thi&#7871;t B&#7883; Qua M&#7841;ng internet'>
	<meta property='og:image'         content='http://123anhdep.net/wp-content/uploads/2016/03/bst-hinh-anh-hai-huoc-nhung-tro-dua-cong-nghe-sieu-vui-nhon-nhat-the-gioi-nhan-ngay-ca-thang-tu-1.jpg'>


<center><h1>V&#361; Tuy&#7875;n Smart Home</h1><br/>&#272;i&#7873;u Khi&#7875;n Thi&#7871;t B&#7883; &#272;i&#7879;n Qua M&#7841;ng internet<form method=post><br>
<font color=red>Nh&#7853;p M&#7853;t Kh&#7849;u &#272;&#7875; K&#7871;t N&#7889;i V&#7899;i M&#7841;ng Wifi:</font> <br/><br/><input type=password name=pass size=20 placeholder='Nh&#7853;p M&#7853;t Kh&#7849;u'>
<input type=submit value='&#272;&#259;ng Nh&#7853;p'>
</form></center>

");
}
}
echo '<center><br/><form method="POST" aciton=""><input type="submit" name="Marion001-Dep-Trai" value="&#272;&#259;ng Xu&#7845;t"></form></center>
<iframe scrolling="no" width="100%" height="100%" src="http://vutuyen.ddns.info/" frameborder="0" allowfullscreen="true">
</iframe>


';





?>

